import User from './Models/User';
import Post from './Models/Post';
import Chat from './Models/Chat';
import ChatMessage from './Models/ChatMessage';

export interface FirebaseContextType {
    posts: Post[];
    users: User[];
    chats: Chat[];
    currentUser: User | null;
    currentUserID: string;
  
    addPost: (title: string, images: string[], uid: string) => Promise<void>;
    addRemoveLike: (id: string, isLiked: boolean) => Promise<void>;
    addComment: (id: string, comment: string) => Promise<void>;
    adjustFollowing: (id: string, isFollowed: boolean) => Promise<void>;
    getGroupMessages: (groupName: string, callback: (messages: ChatMessage[]) => void) => void;
  }
  export interface SocketServiceContextProps {
    connect: (groupName: string) => void;
    disconnect: () => void;
    joinGroup: (groupName: string) => void;
    leaveGroup: (groupName: string) => void;
    sendMessage: (message: string, user: string, userId: string, image: string) => void;
    getMessages: (group: string) => ChatMessage[];
    currentGroup: string | null;
  }