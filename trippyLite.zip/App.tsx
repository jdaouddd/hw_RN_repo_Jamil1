import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Icon from 'react-native-vector-icons/Ionicons';

import { FirebaseProvider } from './root/FirebaseContext';
import { SocketServiceProvider } from './root/SocketService';

import FeedView from './Views/FeedView';
import PostView from './Views/PostView';
import ProfileView from './Views/ProfileView';
import ChatStackNavigator from './Views/ChatStackNavigator'; 
import { RouteProp } from '@react-navigation/native';
import { BottomTabNavigationOptions } from '@react-navigation/bottom-tabs';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <FirebaseProvider>
      <SocketServiceProvider>
        <NavigationContainer>
        <Tab.Navigator
  screenOptions={({ route }: { route: RouteProp<Record<string, object | undefined>, string> }): BottomTabNavigationOptions => ({
    tabBarIcon: ({ color, size }: { color: string; size: number }) => {
      let iconName = '';

      if (route.name === 'Feed') {
        iconName = 'list';
      } else if (route.name === 'Post') {
        iconName = 'add-circle';
      } else if (route.name === 'Profile') {
        iconName = 'person';
      } else if (route.name === 'Chat') {
        iconName = 'chatbubble';
      }

      return <Icon name={iconName} size={size} color={color} />;
    },
    headerShown: false,
    tabBarActiveTintColor: '#3478F6',
    tabBarStyle: { backgroundColor: '#F5E5D3' },
  })}
>
            <Tab.Screen name="Feed" component={FeedView} />
            <Tab.Screen name="Post" component={PostView} />
            <Tab.Screen name="Profile" component={ProfileView} />
            <Tab.Screen name="Chat" component={ChatStackNavigator} />
          </Tab.Navigator>
        </NavigationContainer>
      </SocketServiceProvider>
    </FirebaseProvider>
  );
}
