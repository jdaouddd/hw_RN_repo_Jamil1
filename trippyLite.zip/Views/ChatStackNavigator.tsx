import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import ChatsView from './ChatsView';
import ChatView from './ChatView';

const Stack = createNativeStackNavigator();

const ChatStackNavigator = () => {
  return (
    <Stack.Navigator
      initialRouteName="Chats"
      screenOptions={{
        headerShown: false, // set to true if you want headers
      }}
    >
      <Stack.Screen name="Chats" component={ChatsView} />
      <Stack.Screen name="Chat" component={ChatView} />
    </Stack.Navigator>
  );
};

export default ChatStackNavigator;
