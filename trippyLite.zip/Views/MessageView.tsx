import React from 'react';
import { View, Text, StyleSheet, Image, Dimensions } from 'react-native';
import  text  from '../Models/ChatMessage'; 

type MessageViewProps = {
  message: text;
  sent: boolean;
};

const MessageView: React.FC<MessageViewProps> = ({ message, sent }) => {
  return (
    <View style={[styles.container, sent ? styles.alignRight : styles.alignLeft]}>
      <View style={styles.avatar}>
        <Image source={{ uri: message.image }} style={{ width: 24, height: 24, borderRadius: 12 }} />
      </View>
      <View style={[styles.messageBubble, sent ? styles.sentBubble : styles.receivedBubble]}>
        <Text style={styles.senderName}>{message.sender}</Text>
        <Text style={styles.messageText}>{message.text}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginBottom: 10,
  },
  alignLeft: {
    justifyContent: 'flex-start',
  },
  alignRight: {
    justifyContent: 'flex-end',
  },
  avatar: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#A43A3A',
    marginRight: 10,
  },
  messageBubble: {
    maxWidth: Dimensions.get('window').width * 0.7,
    padding: 10,
    borderRadius: 8,
  },
  sentBubble: {
    backgroundColor: '#F5E5D3',
    alignSelf: 'flex-end',
  },
  receivedBubble: {
    backgroundColor: '#F0F0F0',
    alignSelf: 'flex-start',
  },
  senderName: {
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 2,
    color: '#A43A3A',
  },
  messageText: {
    fontSize: 16,
    color: '#000',
  },
});

export default MessageView;

