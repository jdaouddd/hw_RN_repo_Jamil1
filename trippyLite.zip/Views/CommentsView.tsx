import React from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  FlatList,
  TouchableOpacity,
  Dimensions,
  StyleSheet,
} from 'react-native';

const height = Dimensions.get('window').height;

type CommentsViewProps = {
  visible: boolean;
  onClose: () => void;
};

const CommentsView: React.FC<CommentsViewProps> = ({ visible, onClose }) => {
  return (
    <Modal
      visible={visible}
      onRequestClose={onClose}
      transparent
      animationType="slide"
    >
      <View style={styles.fullScreenModal}>
        <View style={styles.modalContainer}>
          <Text style={styles.modalTitle}>Comments</Text>
          {/* Your UI components like FlatList for comments, TextInput, etc. */}
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  fullScreenModal: {
    margin: 0,
    justifyContent: 'flex-end',
  },
  modalContainer: {
    backgroundColor: '#F5E5D3',
    height: height * 0.5,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 15,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  commentList: {
    paddingVertical: 10,
    flexGrow: 1,
  },
  commentInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  commentInput: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderColor: '#E0B1AD',
    borderRadius: 5,
    paddingHorizontal: 10,
    color: 'black',
  },
});

export default CommentsView;

