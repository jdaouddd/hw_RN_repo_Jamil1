import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

// Define the props structure
interface PostItemProps {
  post: {
    id: string;
    title: string;
    images: string[];
    uid: string;
    likes: string[];
    comments: any[];
    username: string;
    userimage: string;
  };
}

const PostItemView: React.FC<PostItemProps> = ({ post }) => {
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likes.length);

  const handleLike = () => {
    if (liked) {
      setLikeCount((prev) => prev - 1);
    } else {
      setLikeCount((prev) => prev + 1);
    }
    setLiked(!liked);
  };

  return (
    <View style={postItemStyles.container}>
      <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 10 }}>
        <Image
          source={{ uri: post.userimage }}
          style={[{ width: 40, height: 40, borderRadius: 20 }, postItemStyles.userImage]}
        />
        <Text>{post.username}</Text>
      </View>

      <Image source={{ uri: post.images[0] }} style={[{ width: '100%', height: 250 }, postItemStyles.postImage]} />

      <View style={postItemStyles.actionRow}>
        <TouchableOpacity onPress={handleLike}>
          <FontAwesome
            name={liked ? 'heart' : 'heart-o'}
            size={24}
            color={liked ? 'red' : 'black'}
            style={postItemStyles.icon}
          />
        </TouchableOpacity>
        <Text style={postItemStyles.likes}>{likeCount} likes</Text>
      </View>

      <Text style={postItemStyles.title}>{post.title}</Text>
    </View>
  );
};

export default PostItemView;

const postItemStyles = StyleSheet.create({
  container: {
    marginBottom: 20,
    elevation: 3,
    marginLeft: 5,
  },
  userImage: {
    marginLeft: 10,
  },
  postImage: {
    borderRadius: 10,
    marginHorizontal: 5,
  },
  actionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  icon: {
    marginHorizontal: 5,
  },
  likes: {
    fontSize: 18,
    marginRight: 10,
  },
  title: {
    fontSize: 18,
    textAlign: 'left',
    marginLeft: 20,
  },
});
