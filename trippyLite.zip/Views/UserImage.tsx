export const userImageStyles = {
    container: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 10,
    },
    image: {
      borderRadius: 30,
      borderWidth: 1,
      borderColor: 'red',
      overflow: 'hidden',
    },
    loader: {
      position: 'absolute',
    },
    errorText: {
      color: 'red',
      fontSize: 12,
    },
    name: {
      marginLeft: 10,
      color: 'black',
    },
  };
  