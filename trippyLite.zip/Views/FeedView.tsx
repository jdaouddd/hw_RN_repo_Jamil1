import React from 'react';
import { View, StyleSheet, TextInput } from 'react-native';

const FeedView = () => {
  return (
    <View style={styles.container}>
      <View style={styles.searchBar}>
        <TextInput style={styles.searchText} placeholder="Search users..." />
      </View>
      <View style={styles.filteredUsersContainer}>
        {/* users */}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
  },
  searchBar: {
    flexDirection: 'row',
    height: 40,
    backgroundColor: '#F5E5D3',
    borderRadius: 20,
    paddingHorizontal: 10,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#E0B1AD',
    marginLeft: 10,
    marginRight: 10,
  },
  searchIcon: {
    marginRight: 5,
    marginTop: 9,
  },
  searchText: {
    fontSize: 18,
  },
  filteredUsersContainer: {
    paddingBottom: 10,
  },
});

export default FeedView;
