import React from 'react';
import { View, TextInput, StyleSheet, Text } from 'react-native';

const ChatView = () => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.groupName}>Group Name</Text>
      </View>
      <View style={styles.messagesContainer}>
        {/* messages */}
      </View>
      <View style={styles.inputContainer}>
        <TextInput style={styles.input} placeholder="Type a message" />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5E5D3',
  },
  header: {
    padding: 15,
    alignItems: 'center',
    backgroundColor: '#F5E5D3',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  groupName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4A3A3A',
  },
  messagesContainer: {
    padding: 10,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    backgroundColor: '#F5E5D3',
  },
  input: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderColor: '#E0B1AD',
    borderRadius: 25,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#FFF',
    color: '#000',
  },
});

export default ChatView;
