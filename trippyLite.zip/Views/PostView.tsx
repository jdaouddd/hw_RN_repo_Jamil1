import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { useFirebase } from '../root/FirebaseContext';

const PostView = () => {
  const [title, setTitle] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const firebase = useFirebase(); // Assumes context is setup
  const uid = 'Hg98iGBTXZCLapoAXYNO'; // Hardcoded for now

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      allowsMultipleSelection: false,
      quality: 1,
    });

    if (!result.canceled) {
      const uri = result.assets[0].uri;
      setImages([...images, uri]);
    }
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      await firebase.addPost(title, images, uid);
      setMessage('✅ Post submitted successfully!');
      setTitle('');
      setImages([]);
    } catch (error) {
      setMessage('❌ Error submitting post.');
    }
    setLoading(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Title</Text>
      <TextInput
        value={title}
        onChangeText={setTitle}
        style={styles.input}
        placeholder="Enter a title"
        placeholderTextColor="#aaa"
      />

      <ScrollView horizontal style={styles.imageScroll}>
        {images.map((img, index) => (
          <Image
            key={index}
            source={{ uri: img }}
            style={styles.imagePreview}
          />
        ))}
        <TouchableOpacity style={styles.imagePicker} onPress={pickImage}>
          <Text style={styles.imagePickerText}>+</Text>
        </TouchableOpacity>
      </ScrollView>

      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.buttonText}>Submit Post</Text>
        )}
      </TouchableOpacity>

      {message !== '' && <Text style={styles.message}>{message}</Text>}
    </View>
  );
};

export default PostView;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#F5E5D3',
  },
  label: {
    fontSize: 20,
    color: '#D28288',
    marginBottom: 10,
    marginLeft: 15,
  },
  input: {
    borderColor: '#D17E85',
    borderWidth: 2,
    borderRadius: 25,
    marginHorizontal: 15,
    backgroundColor: '#F5E5D3',
    marginBottom: 20,
    padding: 10,
  },
  imageScroll: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  imagePicker: {
    width: 175,
    height: 175,
    backgroundColor: '#DED4C7',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    marginHorizontal: 10,
  },
  imagePickerText: {
    color: '#C87780',
    fontSize: 14,
  },
  imagePreview: {
    width: 175,
    height: 175,
    borderRadius: 10,
    marginHorizontal: 10,
  },
  button: {
    backgroundColor: '#D58F93',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  message: {
    marginTop: 10,
    fontSize: 16,
    color: '#A43A3A',
    textAlign: 'center',
  },
});


