
import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import PostItemView from './PostItemView';

// Dummy user and post data
const dummyUser = {
  name: 'John Doe',
  image: 'https://placekitten.com/200/200',
  postsCount: 12,
  followers: 340,
  following: 180,
};

const dummyPosts = [
  {
    id: '1',
    title: 'My first post!',
    images: ['https://placekitten.com/400/400'],
    uid: 'user123',
    likes: [],
    comments: [],
    username: 'johndoe',
    userimage: dummyUser.image,
  },
  {
    id: '2',
    title: 'Loving this day',
    images: ['https://placekitten.com/410/410'],
    uid: 'user123',
    likes: [],
    comments: [],
    username: 'johndoe',
    userimage: dummyUser.image,
  },
];

const ProfileView = () => {
  const [following, setFollowing] = useState(false);

  const handleFollowToggle = () => {
    setFollowing((prev) => !prev);
  };

  return (
    <View style={profileViewStyles.container}>
      <View style={profileViewStyles.header}>
        <Image source={{ uri: dummyUser.image }} style={profileViewStyles.profileImage} />
        <View style={profileViewStyles.userInfo}>
          <Text style={profileViewStyles.userName}>{dummyUser.name}</Text>
          <Text style={profileViewStyles.userStats}>
            Posts: {dummyUser.postsCount} | Followers: {dummyUser.followers} | Following: {dummyUser.following}
          </Text>
        </View>
      </View>

      <TouchableOpacity
        style={[
          profileViewStyles.followButton,
          following ? profileViewStyles.following : profileViewStyles.notFollowing,
        ]}
        onPress={handleFollowToggle}
      >
        <Text
          style={[
            profileViewStyles.followButtonText,
            following ? profileViewStyles.followingText : profileViewStyles.notFollowingText,
          ]}
        >
          {following ? 'Following' : 'Follow'}
        </Text>
      </TouchableOpacity>

      <FlatList
        data={dummyPosts}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <PostItemView post={item} />}
      />
    </View>
  );
};

export default ProfileView;

const profileViewStyles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: '#F5E5D3',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  profileImage: {
    width: 75,
    height: 75,
    borderRadius: 37.5,
    borderWidth: 2,
    borderColor: '#A43A3A',
  },
  userInfo: {
    marginLeft: 15,
    flex: 1,
  },
  userName: {
    fontSize: 36,
    fontFamily: 'Chillax',
    color: '#000',
  },
  userStats: {
    fontSize: 14,
    fontFamily: 'Chillax',
    color: '#333',
    marginTop: 5,
  },
  followButton: {
    marginTop: 15,
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 3,
  },
  following: {
    backgroundColor: '#A43A3A',
  },
  notFollowing: {
    backgroundColor: '#fff',
    borderWidth: 2,
    borderColor: '#A43A3A',
  },
  followButtonText: {
    fontSize: 16,
    fontFamily: 'Chillax',
  },
  followingText: {
    color: '#fff',
  },
  notFollowingText: {
    color: '#A43A3A',
  },
});
