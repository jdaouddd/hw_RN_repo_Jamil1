import React, { ReactNode } from 'react';
import { View, StyleSheet } from 'react-native';

type Props = {
  children: ReactNode;
};

const BackgroundView: React.FC<Props> = ({ children }) => {
  return <View style={styles.container}>{children}</View>;
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default BackgroundView;

