import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

type Comment = {
  id: string;
  text: string;
  username: string;
  userimage: string;
};

type Props = {
  comment: Comment;
};

const CommentItemView: React.FC<Props> = ({ comment }) => {
  return (
    <View style={styles.container}>
      <View style={styles.userImage}>
        {/* You can render Image here if needed */}
      </View>
      <View>
        <Text style={styles.username}>{comment.username}</Text>
        <Text style={styles.text}>{comment.text}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    elevation: 3,
    flexDirection: 'row',
    marginVertical: 8,
  },
  userImage: {
    width: 33,
    height: 33,
    borderRadius: 30,
    marginRight: 10,
  },
  username: {
    fontWeight: 'bold',
    marginBottom: 2,
  },
  text: {
    fontSize: 14,
  },
});

export default CommentItemView;

