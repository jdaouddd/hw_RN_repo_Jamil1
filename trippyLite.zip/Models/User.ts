import * as CryptoJS from 'crypto-js';

export default class User {
  id?: string;
  name: string;
  following: string[];
  image: string;
  userLiked: string[];

  constructor(
    id: string | undefined,
    name: string,
    following: string[],
    image: string,
    userLiked: string[]
  ) {
    this.id = id;
    this.name = name;
    this.following = following;
    this.image = image;
    this.userLiked = userLiked;
  }

  hash() {
    const hashString = `${this.name}:${this.following}:${this.image}`;
    return CryptoJS.SHA256(hashString).toString();
  }

  static equals(prof1: User, prof2: User) {
    return prof1.name === prof2.name;
  }

  static compare(prof1: User, prof2: User) {
    return prof1.name < prof2.name;
  }
}
