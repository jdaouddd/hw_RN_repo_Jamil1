export default class Chat {
    id: string;
    image: string;
  
    constructor(id: string, image: string) {
      this.id = id;
      this.image = image;
    }
  }
  