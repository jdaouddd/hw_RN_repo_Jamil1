export default class ChatMessage {
    id: string;
    groupName: string;
    sender: string;
    senderId: string;
    text: string;
    image: string;
    timestamp: any; 
  
    constructor(
      id: string,
      groupName: string,
      sender: string,
      senderId: string,
      text: string,
      image: string,
      timestamp: any
    ) {
      this.id = id;
      this.groupName = groupName;
      this.sender = sender;
      this.senderId = senderId;
      this.text = text;
      this.image = image;
      this.timestamp = timestamp;
    }
  }
  