export default class Comment {
    id: string;
    text: string;
    username: string;
    userimage: string;
  
    constructor(id: string, text: string, username: string, userimage: string) {
      this.id = id;
      this.text = text;
      this.username = username;
      this.userimage = userimage;
    }
  }
  