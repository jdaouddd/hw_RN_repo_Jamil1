import Comment from './Comment';

export default class Post {
  id: string;
  title: string;
  images: string[];
  uid: string;
  likes: number;
  comments: Comment[];
  username: string;
  userimage: string;

  constructor(
    id: string,
    title: string,
    images: string[],
    uid: string,
    likes: number,
    comments: Comment[],
    username: string,
    userimage: string
  ) {
    this.id = id;
    this.title = title;
    this.images = images;
    this.uid = uid;
    this.likes = likes;
    this.comments = comments;
    this.username = username;
    this.userimage = userimage;
  }
}
