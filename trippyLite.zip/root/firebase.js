import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';


// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDp497-Nl43rwXYFSRfF0q0WMy5BCTYVg",
    authDomain: "trippylite-e8ecd.firebaseapp.com",
    projectId: "trippylite-e8ecd",
    storageBucket: "trippylite-e8ecd.appspot.com",
    messagingSenderId: "1041980643518",
    appId: "1:133588131505:ios:efbcc36a8fa9e97c0b0c90"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore
const db = getFirestore(app);



export { db };
