import React, { createContext, useState, useEffect,
    ReactNode } from 'react';
    import { db } from './firebase';
    import { useContext } from 'react';
    import {
    collection,
    getDoc,
    addDoc,
    updateDoc,
    doc,
    onSnapshot,
    query,
    orderBy,
    arrayUnion,
    increment
    } from 'firebase/firestore';
    import { getStorage, ref, uploadBytes, getDownloadURL } from
    'firebase/storage';
    import { FirebaseContextType } from '../types';
    import User from '../Models/User';
    import Post from '../Models/Post';
    import Chat from '../Models/Chat';
    import ChatMessage from '../Models/ChatMessage';

    export const FirebaseContext = createContext<FirebaseContextType | null>(null);

    const FirebaseProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
      const [users, setUsers] = useState<User[]>([]);
      const [posts, setPosts] = useState<Post[]>([]);
      const [chats, setChats] = useState<Chat[]>([]);
      const [currentUser, setCurrentUser] = useState<User | null>(null);
    
      const currentUserID = 'Hg98iGBTXZCLapoAXYNO'; // Hardcoded for now
    
      // Fetch users
      const getUsers = () => {
        const usersRef = collection(db, 'users');
        const unsubscribe = onSnapshot(usersRef, (snapshot) => {
          const userData = snapshot.docs.map((doc) => ({
            ...doc.data(),
            id: doc.id,
          })) as User[];
    
          setUsers(userData);
    
          const loggedInUser = userData.find((user) => user.id === currentUserID) || null;
          setCurrentUser(loggedInUser);
        });
    
        return unsubscribe;
      };
    
      // Fetch posts
      const getPosts = () => {
        const postsRef = collection(db, 'posts');
        const unsubscribe = onSnapshot(postsRef, (snapshot) => {
          const postData = snapshot.docs.map((doc) => ({
            ...doc.data(),
            id: doc.id,
          })) as Post[];
          setPosts(postData);
        });
    
        return unsubscribe;
      };
    
      // Fetch chats
      const getChats = () => {
        const chatsRef = collection(db, 'chats');
        const unsubscribe = onSnapshot(chatsRef, (snapshot) => {
          const chatData = snapshot.docs.map((doc) => ({
            ...doc.data(),
            id: doc.id,
          })) as Chat[];
          setChats(chatData);
        });
    
        return unsubscribe;
      };
    
      // Add a new post
      const addPost = async (title: string, images: string[], uid: string) => {
        const storage = getStorage();
    
        const uploadImage = async (image: string) => {
          const response = await fetch(image);
          const blob = await response.blob();
          const imageName = `${uid}-${Date.now()}.jpg`;
          const imageRef = ref(storage, imageName);
          await uploadBytes(imageRef, blob);
          return await getDownloadURL(imageRef);
        };
    
        const imageUrls = await Promise.all(images.map(uploadImage));
    
        const newPost = {
          title,
          uid,
          comments: [],
          images: imageUrls,
          likes: 0,
          username: currentUser?.name,
          userimage: currentUser?.image,
        };
    
        await updateDoc(doc(db, 'posts', uid), newPost); // Optionally use addDoc to create a new post with auto-id
      };
    
      // Like/Unlike a post
      const addRemoveLike = async (id: string, isLiked: boolean) => {
        const postRef = doc(db, 'posts', id);
        const postSnapshot = await getDoc(postRef);
        const postData = postSnapshot.data();
    
        await updateDoc(postRef, {
          likes: increment(isLiked ? 1 : -1),
        });
    
        if (currentUser) {
          const userRef = doc(db, 'users', currentUserID);
          const updateLikedPosts = isLiked
            ? [...(currentUser.userLiked || []), id]
            : (currentUser.userLiked || []).filter((postId) => postId !== id);
    
          await updateDoc(userRef, { userLiked: updateLikedPosts });
        }
      };
    
      // Add comment to post
      const addComment = async (id: string, comment: string) => {
        const postRef = doc(db, 'posts', id);
    
        const newComment = {
          id: `${Date.now()}`,
          text: comment,
          username: currentUser?.name || 'Anonymous',
          userimage: currentUser?.image || '',
        };
    
        await updateDoc(postRef, {
          comments: arrayUnion(newComment),
        });
      };
    
      // Follow/Unfollow user
      const adjustFollowing = async (id: string, isFollowed: boolean) => {
        const userRef = doc(db, 'users', currentUserID);
        const updateFollowing = isFollowed
          ? [...(currentUser?.following || []), id]
          : (currentUser?.following || []).filter((userId) => userId !== id);
    
        await updateDoc(userRef, { following: updateFollowing });
      };
    
      // Get group messages
      const getGroupMessages = (
        groupName: string,
        callback: (messages: ChatMessage[]) => void
      ) => {
        const groupMessagesRef = collection(db, 'chats', groupName, 'messages');
        const messagesQuery = query(groupMessagesRef, orderBy('timestamp', 'asc'));
    
        onSnapshot(messagesQuery, (snapshot) => {
          const messages = snapshot.docs.map((doc) => ({
            id: doc.id,
            groupName,
            ...doc.data(),
          })) as ChatMessage[];
    
          callback(messages);
        });
      };
    
      useEffect(() => {
        const unsubUsers = getUsers();
        const unsubPosts = getPosts();
        const unsubChats = getChats();
    
        return () => {
          unsubUsers();
          unsubPosts();
          unsubChats();
        };
      }, []);
    
      return (
        <FirebaseContext.Provider
          value={{
            posts,
            users,
            chats,
            currentUser,
            currentUserID,
            addPost,
            addRemoveLike,
            addComment,
            adjustFollowing,
            getGroupMessages,
          }}
        >
          {children}
        </FirebaseContext.Provider>
      );
    };
    export const useFirebase = () => {
        const context = useContext(FirebaseContext);
        if (!context) {
          throw new Error('useFirebase must be used within a FirebaseProvider');
        }
        return context;
      };
    
    export { FirebaseProvider };