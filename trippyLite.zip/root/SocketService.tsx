import React, { createContext, useContext, useEffect, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import { FirebaseContext } from './FirebaseContext';
import ChatMessage from '../Models/ChatMessage';
import { SocketServiceContextProps } from '../types';

// Create socket context
const SocketServiceContext = createContext<SocketServiceContextProps | null>(null);

export const SocketServiceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // State management
  const [socket, setSocket] = useState<Socket | null>(null);
  const [groupMessages, setGroupMessages] = useState<Record<string, ChatMessage[]>>({});
  const [currentGroup, setCurrentGroup] = useState<string | null>(null);

  const firebase = useContext(FirebaseContext);

  // Initialize socket connection
  useEffect(() => {
    const newSocket = io('http://localhost:8080', { transports: ['websocket'] });
    setSocket(newSocket);

    newSocket.on('connect', () => {
      console.log('Connected to WebSocket server!');
    });

    newSocket.on('disconnect', () => {
      console.log('Disconnected from WebSocket server');
    });

    // Handle incoming messages
    newSocket.on('receiveMessage', (data: ChatMessage) => {
      setGroupMessages((prev) => ({
        ...prev,
        [data.groupName]: [...(prev[data.groupName] || []), data],
      }));
    });

    newSocket.on('error', (error: any) => {
      console.error('Socket error:', error);
    });

    // Cleanup on unmount
    return () => {
      newSocket.disconnect();
    };
  }, []);

  // Connect to a chat group
  const connect = (groupName: string) => {
    if (!socket) return;

    if (socket.connected) {
      console.log('Socket already connected');
      joinGroup(groupName);
    } else {
      socket.connect();
      socket.on('connect', () => {
        joinGroup(groupName);
      });
    }
  };

  // Disconnect from server
  const disconnect = () => {
    socket?.disconnect();
  };

  // Join a specific group
  const joinGroup = (groupName: string) => {
    if (currentGroup === groupName) return;

    console.log(`Joined group ${groupName}`);
    socket?.emit('joinGroup', groupName);
    setCurrentGroup(groupName);

    // Load group messages from Firebase
    firebase?.getGroupMessages(groupName, (messages: ChatMessage[]) => {
      setGroupMessages((prev) => ({
        ...prev,
        [groupName]: messages.length > 0 ? messages : [],
      }));
    });
  };

  // Leave a group
  const leaveGroup = (groupName: string) => {
    if (!socket) return;

    console.log(`Left group ${groupName}`);
    socket.emit('leaveGroup', groupName);
    setCurrentGroup(null);
  };

  // Send a message to current group
  const sendMessage = (message: string, user: string, userId: string, image: string) => {
    if (!currentGroup || !socket) return;

    console.log('Sending message:', message, user, userId, image);
    socket.emit('sendMessage', {
      groupName: currentGroup,
      sender: user,
      senderId: userId,
      message,
      image,
    });
  };

  // Get messages for a specific group
  const getMessages = (group: string): ChatMessage[] => {
    return groupMessages[group] || [];
  };

  // Provide socket context to children
  return (
    <SocketServiceContext.Provider
      value={{
        connect,
        disconnect,
        joinGroup,
        leaveGroup,
        sendMessage,
        getMessages,
        currentGroup,
      }}
    >
      {children}
    </SocketServiceContext.Provider>
  );
};

// Custom hook to use socket service
export const useSocketService = (): SocketServiceContextProps => {
  const context = useContext(SocketServiceContext);
  if (!context) {
    throw new Error('useSocketService must be used within a SocketServiceProvider');
  }
  return context;
};
